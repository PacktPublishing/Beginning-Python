#!/usr/bin/env python

from PIL import Image

# Explain that it is easier to install using python 2.*

# http://pillow.readthedocs.org/en/3.1.x/reference/Image.html
# https://pillow.readthedocs.org/en/3.2.x/installation.html

# You must not have PIL already installed if you want pillow
# pip should already come installed, but just in case show them manual install anyways

rose = Image.open('rose.jpg')
rose.show()









