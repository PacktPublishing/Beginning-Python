#!/usr/bin/env python

from PIL import Image

rodents = Image.open('rodents.jpeg')
rodents.show()









