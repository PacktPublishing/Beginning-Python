#!/usr/bin/env python

from PIL import Image, ImageFilter, ImageEnhance

rodents_img = Image.open('rodents.jpeg')

rodents_img.show()
grayscale = rodents_img.convert('L')
edge_detect = rodents_img.filter(ImageFilter.FIND_EDGES)
contrast = ImageEnhance.Contrast(rodents_img).enhance(3.5)
bright = ImageEnhance.Brightness(rodents_img).enhance(5)
contrast.show()
bright.show()






