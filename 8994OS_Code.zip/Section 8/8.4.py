#!/usr/bin/env python
from PIL import Image

rose_img = Image.open('rose.png')
rose_img.show()
width, height = rose_img.size # (w, h)
for x in range(width):
	for y in range(height):
		
		pixel_coordinate = (x, y)
		r, g, b, alpha = rose_img.getpixel(pixel_coordinate)
		
		negative_color = (255 - r, 255 - g, 255 - b)
		rose_img.putpixel( pixel_coordinate, negative_color )

rose_img.show()









