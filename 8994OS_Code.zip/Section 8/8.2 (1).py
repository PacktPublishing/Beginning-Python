#!/usr/bin/env python

from PIL import Image, ImageFilter, ImageEnhance

rodents = Image.open('rodents.jpeg')

grayscale   = rodents.convert('L')
edge_detect = rodents.filter(ImageFilter.FIND_EDGES)
constrast   = ImageEnhance.Contrast(rodents).enhance(1.5)
bright      = ImageEnhance.Brightness(rodents).enhance(2)

rodents.show()
# bright.show()
# constrast.show()
edge_detect.show()
grayscale.show()









