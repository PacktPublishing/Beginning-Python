#!/usr/bin/env python

from PIL import Image

rose_img = Image.open('rose.jpg')
rose_img.show()


