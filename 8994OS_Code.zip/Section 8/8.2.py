#!/usr/bin/env python
from PIL import Image


def resize_images( image_names, new_size = (200, 200) ):
	
	for image_name in image_names:
		
		img = Image.open(image_name)
		img = img.resize(new_size)
		img.save("resized_"+image_name)

images = ["giraffes.jpg", "python.jpeg", "rodents.jpeg"]
resize_images(images)

python_img = Image.open("python.jpeg")
python_img.show()
python_img = python_img.crop( (100, 100, 300, 300) )
python_img = python_img.rotate(90)
python_img.show()




