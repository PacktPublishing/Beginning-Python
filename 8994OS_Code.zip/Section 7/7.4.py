#!/usr/local/bin/python3.4

import string_functions
print(__name__)







