#!/usr/local/bin/python3.4


import math
from math import pi
from math import pi as PIE
from math import *

print( math.pi )
print( math.e )
print( math.cos(math.pi) ) # -1
print( math.cos(math.pi/2) ) # 0

print( math.factorial(4) )

print(pi)
print(pi)
print(PIE)








