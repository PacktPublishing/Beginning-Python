#!/usr/local/bin/python3.4

from math import factorial as f

print(f(0))
print(f(1))
print(f(2))
print(f(3))
print(f(4))





