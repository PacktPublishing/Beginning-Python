#!/usr/local/bin/python3.4

import shutil
import string
import ftplib

# print(string.ascii_letters)
# shutil.copyfile('test', 'test_cp')





