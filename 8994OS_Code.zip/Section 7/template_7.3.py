#!/usr/local/bin/python3.4

import tmp_volumes
from tmp_volumes import *

# print(dir(tmp_volumes))

sphere_radius = 5.0

cone_r = 4.0
cone_h = 3.5

print(sphere_vol(sphere_radius))
print(cone_vol(cone_r, cone_h))
print(cube_vol(2,3,4))











