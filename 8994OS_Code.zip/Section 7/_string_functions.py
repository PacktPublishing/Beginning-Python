

def first_half(s):
  return s[:len(s)/2]
def last_half(s):
  return s[len(s)/2:]

print("String functions module name: " + __name__)

# If we are executing this file and not importing it
if __name__ == '__main__':
  

  print("Executes")  
  assert first_half("1234") == "12",  "First half failing" 
  assert last_half("1234") == "34", "Second half failing"


