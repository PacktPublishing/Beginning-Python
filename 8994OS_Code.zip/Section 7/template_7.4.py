#!/usr/local/bin/python3.4

import _string_functions
print(__name__)










