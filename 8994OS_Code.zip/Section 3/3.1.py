#!/usr/local/bin/python3.4

numbers = [5, -6, 2, 4, -5, 1]
names = ["Heather", "Micah", "Jane"]

print(names[0])
print(names[1])
print(names[2])

print(names)
del names[1]
print(names)


mystr = "Hello world"
print(mystr[0])
print(mystr[6])
del mystr[2]

