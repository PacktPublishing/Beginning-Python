#!/usr/local/bin/python3.4

numbers = [3.14, -5, 10, 10**4, 17 ]
hello_world = "HelloWorld" 

# min, max, sum, len

# print(min(numbers))
# print(max(numbers))
# print(sum(numbers))
# print(len(numbers))
print(max(hello_world))
print(min(hello_world))
# print(sum(hello_world))
print(len(hello_world))

