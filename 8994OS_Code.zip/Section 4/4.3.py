#!/usr/local/bin/python3.4
# else and elif

name = "Sarah"
if name == "John":
	print("John")
else:
	print("name was not john")

if name == "Emily":
	print("Emily")
elif name == "Mike":
	print("Mike")
elif name == "Bob":
	print("Bob")
else:
	print("not Emily, not Mike, and not bob")

if name == "Emily":
	print("Emily")

if name == "Mike":
	print("Mike")

if name == "Bob":
	print("Bob")

n = 77
if n < 20:
	print("n < 20")
elif n < 40:
	print("n < 40")
elif n < 60:
	print("n < 60")
else:
	print("n >= 60")





