#!/usr/local/bin/python3.4

age = 35
if age == 35:
	print("Age is equal to 35!")

name = "susan"
if name == "Megan":
	print("Yes my name is Megan!")
	if age == 35:
		print("My name is Megan and I am 35 years old!")	