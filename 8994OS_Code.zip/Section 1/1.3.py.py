
name = "William Fiset"
number = "1234"

a = "A"

_name = "William Fiset"

camelCaseConvention = "camelCaseConvention"
underscore_convention = "underscore_convention"

# PEP8
