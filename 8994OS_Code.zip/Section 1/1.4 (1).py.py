
# -*- coding: utf-8 -*-

# To express different types sure as numbers, 
# sequences of characters
# decimal numbers we need different representations 

string = "A string is simple a sequence of characters"
string = '√4 = ±2'
string = '♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥'
print(string)

integer = 123
integer = -5
print(type(integer))
integer = 235345394058230942039572038502302398402394
print(type(integer))

# decimal numbers (called flota, reals, and doubles)
# doubles have higher precision than float in other langs

decimal_num = 3.14159
print(decimal_num)
decimal_num = 4.23423490238420934823094
print(decimal_num)

a = 3.4
b = 3.9
c = 5

# Casting
print(a, int(a))
print(b, int(b))
print(c, float(c))










