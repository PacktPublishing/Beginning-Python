# Mention PEP8

# Talk about strings as a sequence of characters
string = "This is a string"
string = '√4 = ±2'
print(string)

# type = int
integer = 123
integer = -5

# this is a long
integer = 2345723095723985823095723094823075203985023958029375402394 
# print(type(integer))


float_num = 3.14159
float_num = 3.1415939045349058340573049583094503497503458

# show truncation issue

a = 3.4
b = 3.9
c = 5

# print(a, int(a))
# print(b, int(b))
# print(c, float(c))







