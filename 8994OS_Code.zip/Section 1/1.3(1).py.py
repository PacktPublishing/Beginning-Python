

number = "12345"
a = "dgsg4fwefwe"

# Not legal
123abc = "AC"
&*(*(^)) = 5

# Legal
_house = "House"

# Naming conventions
camelCaseConvention = "camelCaseConvention"
underscore_convention = "underscore_convention"
