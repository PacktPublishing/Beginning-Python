#!/usr/local/bin/python3.4


print(2+4)
print(3-5)
print(2 - -5)
print(3*8)
print(2**4)

print(7 / 3)
print(7.0 / 3)
print(7 // 3)
print(7.0 // 3)

print( 8 % 5 )
print( 8 % 4 )
