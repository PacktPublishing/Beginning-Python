#!/usr/local/bin/python3.4

numbers = [1,2,3,4,5,6,7,8,9]
my_string = "Packt publishing rocks!"

total = 0
for num in numbers:
	if num % 2 == 0: # even
		# total = total + num
		total += num
print(total)

vowels = ['a', 'e', 'i', 'o', 'u']
characters = []
for ch in my_string:
	
	if ch in vowels: continue
	characters.append(ch)
	
consonants = ''.join(characters)
print(consonants)