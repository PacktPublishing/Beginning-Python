#!/usr/local/bin/python3.4

index = 0
names = ["Josh", "Harry", "Leah", "Micah"]

print("Please make sure a + b = 20")
while True:
	
	a, b = int(input("a: ")), int(input("b: "))
	if a + b == 20:
		print("Stopping loop")
		break
	else:
		print("Please make sure a + b = 20")



