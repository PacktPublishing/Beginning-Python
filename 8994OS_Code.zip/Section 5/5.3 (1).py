#!/usr/local/bin/python3.4

my_list   = [1,2,3,4,5]
my_tuple  = (2,7,8,9,10)
my_string = "Hello World!"

print( '__iter__' in dir(my_list) )
print( '__iter__' in dir(my_tuple) )
print( '__iter__' in dir(my_string) )

my_string_iter = iter(my_string)

while True:
  try:
    next_elem = next(my_string_iter)
    print(next_elem)
  except StopIteration:
    break





