#!/usr/local/bin/python3.4


# while condition: # condition has to be True
#   # code

index = 0
names = ["Josh", "Harry", "Leah", "Micah"]

# for name in names:
#   # do something with 'name'
while index < len(names):
  name = names[index]
  print(name)
  index = index + 1

total = 0
v = 1
while v <= 10:
  total = total + v
  v = v + 1
print(total)


while True:

  a, b = int(input("a: ")), int(input("b: "))
  if a + b > 20:
    break # exit loop
  else:
    print("Make sure a + b > 20!")







