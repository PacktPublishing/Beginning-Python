#!/usr/local/bin/python3.4

PI = 3.141592

def circle_area(r):
  return PI*r*r

def add(a, b):
  return a + b

print(circle_area(5))
print(circle_area(3))
print(circle_area(2))

print(add(3, 5))
print(add(8, -5))
print(add(3, 20))












