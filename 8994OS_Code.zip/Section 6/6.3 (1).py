#!/usr/local/bin/python3.4

max_value = max([4,7,3,2])
chunks  = ".split returns a list of strings separated by spaces".split()
print(chunks)
print(max_value)













