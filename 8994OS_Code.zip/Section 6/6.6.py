#!/usr/local/bin/python3.4

# Doubles the number n
# double(2)  -> 4
# double(15) -> 30
def double(n):
  
  # base case
  if n == 0:
    return 0
  
  # recursive call
  return double(n - 1) + 2


def exponentiate(b, e):
  
  # Base case 
  if (e == 0): return 1
  
  # recursive call
  return exponentiate(b, e-1) * b







