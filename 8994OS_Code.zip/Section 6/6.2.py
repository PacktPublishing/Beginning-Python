#!/usr/local/bin/python3.4

import datetime as dt

def record_time( message, time = dt.datetime.now() ):
	
	# save to file
	print("{:}, time: {:}".format(message, time))

record_time("It is the morning")
record_time("It is the morning", "Feb 22nd, 1998")


def add(*numbers):
	total = 0
	for n in numbers:
		total += n
	return total




