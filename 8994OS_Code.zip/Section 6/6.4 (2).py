#!/usr/local/bin/python3.4

# def reverse(s):

#   chars = list(s)
#   str_len = len(s)
#   for i in range(len(s)/2):
#     tmp = chars[i]
#     chars[i] = chars[str_len - i - 1]
#     chars[str_len - i - 1] = tmp
#   new_str = ''.join(chars)
#   return new_str


def reverse(s):

  new_str = ""
  for i in range(len(s)):
    new_str += s[len(s) - i - 1]
  return new_str


def is_palindrome(s):

  for i in range(len(s)):
    if s[i] != s[len(s) - i - 1]:
      print("Not a palindrome")
      return # return is used to exit function not return a value
  print("Is a palindrome")

is_palindrome("121")












