#!/usr/local/bin/python3.4

# => "123"  -> "321"
# => "abcd" -> "dcba"
# => "11121" -> "12111"
# def reverse(s):
# 	new_str = ""
# 	for i in range(len(s)):
# 		new_str += s[len(s) - i - 1]
# 	return new_str

# is_palindrome
# palindome examples: "1", "121", "abba", "56765", "bbbbb", "",
# def is_palindrome(p):
# 	
# 	for i in range(len(p)//2):
# 		if p[i] != p[len(p) - i - 1]:
# 			print("No this is not a palindrome")
# 			return # exit function
# 			
# 	print("Yes this is a palindrome")

def is_palindrome(s):
	if s == s[::-1]:
		print("Yes this is a palindrome")
	else:
		print("No this is not a palindrome")
		
is_palindrome("1")
is_palindrome("121")
is_palindrome("abba")
is_palindrome("hello")
	








