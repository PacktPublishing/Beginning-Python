#!/usr/local/bin/python3.4


def double(n):
  if n == 0: return 0
  return double(n - 1) + 2

print(double(1))










