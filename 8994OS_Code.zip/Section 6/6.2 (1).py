#!/usr/local/bin/python3.4

import datetime as dt

def record_time( message, time = dt.datetime.now() ):
  
  # Save message to file ..
  print("{:}, time: {:}".format(message, time))

def add(a, b, c):
  return a + b + c

# print uses the same kind of thing
def add(*numbers):
  
  print(numbers) # returns a tuple

  total = 0
  for n in numbers:
    total += n
  return total

record_time("It is the morning")
record_time("Evening", "Feb 23, 1998")










