#!/usr/local/bin/python3.4

def is_even(number):
	
	# Tests to see if number is a multiple of 2
	if number % 2 == 0:
		
		# number was even, display to console
		print("{:d} is even".format(number))
	
	else:
		
		# number was odd, display to console
		print("{:d} is odd".format(number))

max_value = max([3, 6, 2, 9])

chunks  = ".split() returns a list of strings separated by spaces".split()

list_length = len(["a", "b", "c"])

[1, 2, 4, 5].insert(2, 3)

[4, 7, 3, 2].sort()

#print("I return nothing, I just print things to the console")
is_even(7)









