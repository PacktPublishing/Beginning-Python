#!/usr/local/bin/python3.4

def count_vowels( s, i = 0 ):

  if (i == len(s)): return 0
  if s[i] in ('a', 'e', 'i', 'o', 'u'):
    return count_vowels(s, i+1) + 1
  return count_vowels(s, i+1) + 0

def digit_sum(n):
  if n == 0: return 0
  return digit_sum(n / 10) + n % 10

# 1 1 2 3 5 8 13 21 34 55
def fib(n):
  if n == 0 or n == 1:
    return 1
  return fib(n-1) + fib(n-2)

for i in range(10):
  print(fib(i))









