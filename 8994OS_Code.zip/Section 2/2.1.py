#!/usr/local/bin/python3.4

single_quote_str = 'single quotes'
double_quote_str = "double quotes"

sentence1 = 'I "really" like chocolate'
sentence2 = "I 'really' like chocolate"

sentence1 = 'I \'really\' like chocolate'
sentence2 = "I \"really\" like chocolate"

paragraph = '''
This is 
a long paragraph
'''

''' Triple quote strings are also comment blocks!
	They can span multiple lines. '''

# This is a single line comment

print(paragraph)









