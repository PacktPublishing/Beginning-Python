#!/usr/local/bin/python3.4

science = "SCIENCE"
apple = "apples"

print(apple)
apple = apple.upper()
print(apple)

print(science.lower())
print(science.title())

apple = "       apple			"
apple = apple.strip().upper()
print(apple)

